

var table=document.getElementById("Table");
var rIndex;
var edit=document.getElementById("up");

function checkEmptyInput()
{
	var isEmpty=false,
	num=document.getElementById("sno").value,
	s_name=document.getElementById("name").value,
	duration=document.getElementById("dure").value;
	status=document.getElementById("state").value;

	
	if(num == ""){
		alert("s_no can't be empty");
	    isEmpty=true;
	}
	else if(s_name==""){
		alert("sprint can't be empty");
	    isEmpty=true;
	}
	else if(duration==""){
		alert("duration can't be empty");
	    isEmpty=true;
	}
	else if(status==""){
		alert("status can't be empty");
	    isEmpty=true;
	}
	
	return isEmpty;
}

function addHtmlTableRow()
{
    if(!checkEmptyInput()){
		var newRow=table.insertRow(table.length),
		    cell1=newRow.insertCell(0),
			cell2=newRow.insertCell(1),
			cell3=newRow.insertCell(2),
			cell4=newRow.insertCell(3),
			cell5=newRow.insertCell(4),
			cell6=newRow.insertCell(5),



			num=document.getElementById("sno").value,
			s_name=document.getElementById("name").value,
			duration=document.getElementById("dure").value,
			status=document.getElementById("state").value;
            edit=document.getElementById("edit").innerHTML;
			remove=document.getElementById("rem").innerHTML;

			 
		cell1.innerHTML=num;
		cell2.innerHTML=s_name;	
		cell3.innerHTML=duration;
		cell4.innerHTML=status;
		cell5.innerHTML = edit;
		cell6.innerHTML = remove;

selectedRowToInput();

	}
	document.getElementById("sno").value="";
	document.getElementById("name").value="";
	document.getElementById("dure").value="";
	document.getElementById("state").value="";
	
	document.getElementById("sno").focus();

	
}


function selectedRowToInput()
{
    for(var i = 1;i<table.rows.length;i++)
	{
        table.rows[i].onclick=function()
		{
            rIndex=this.rowIndex;
			document.getElementById("sno").value=this.cells[0].innerHTML;
			document.getElementById("name").value=this.cells[1].innerHTML;
			document.getElementById("dure").value=this.cells[2].innerHTML;
			document.getElementById("state").value=this.cells[3].innerHTML;

			
		};
	}
}
selectedRowToInput();

function editHtmlSelectedRow()
{
    var num=document.getElementById("sno").value,
		s_name=document.getElementById("name").value,
		duration=document.getElementById("dure").value;	
		status=document.getElementById("state").value;	

		if(!checkEmptyInput()){

		table.rows[rIndex].cells[0].innerHTML=num;
		table.rows[rIndex].cells[1].innerHTML=s_name;
		table.rows[rIndex].cells[2].innerHTML=duration;
		table.rows[rIndex].cells[3].innerHTML=status;

    }
	document.getElementById("sno").value="";
	document.getElementById("name").value="";
	document.getElementById("dure").value="";
	document.getElementById("state").value="";
	
	document.getElementById("sno").focus();


} 


function removeSelectedRow()
{

	table.deleteRow(rIndex);
	
	document.getElementById("sno").value="";
	document.getElementById("name").value="";
	document.getElementById("dure").value="";
	document.getElementById("state").value="";

	
}       			
  


